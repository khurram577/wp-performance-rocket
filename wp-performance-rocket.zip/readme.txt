=== Performance Rocket ===
Contributors: khurram557
Tags: performance, speed, cache, optimization
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Performance Rocket helps optimize WordPress websites for faster loading times and better performance. Advanced performance optimization plugin focusing on caching, file optimization, image (lazy loading), and database cleanup.

== Installation ==

1. Upload the plugin files to the /wp-content/plugins/performance-rocket directory.
2. Activate the plugin through the 'Plugins' screen in WordPress.

== Changelog ==

= 1.0.0 =
Initial release
